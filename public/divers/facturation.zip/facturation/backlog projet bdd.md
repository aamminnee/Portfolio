# 🧾 **Backlog du projet – Site Web de facturation automatisée**

## 🎯 **Contexte**

La société **XXXX** souhaite que les factures soient désormais générées et gérées automatiquement depuis son **site web**, plutôt qu’à partir du **logiciel de facturation local** actuellement utilisé.
L’équipe **backend** est responsable :

* de la **création de la base de données**,
* de **l’importation** de l’historique de facturation à partir d’un fichier CSV,
* de la **gestion automatisée des factures**, avoirs et clients,
* et du **développement du backend** du site web.

---

## **Épic 1 : Importation et préparation des données de facturation**

### 🎯 Objectif :

Importer les anciennes données issues du logiciel existant et les structurer proprement pour permettre une exploitation automatique et évolutive.

### 🧩 **User Stories**

* **US1.1** : En tant que développeur, je veux importer un fichier CSV contenant l’historique des factures dans une table brute pour analyser et transformer les données.
* **US1.2** : En tant que développeur, je veux identifier et documenter les champs du CSV (nom, signification, type, utilité).
* **US1.3** : En tant que concepteur de base, je veux produire un **MCD** conforme à la logique de facturation.

### ✅ **Tâches**

* Créer la table `import_brut` pour stocker les données CSV.
* Importer le CSV sans altérer sa structure.
* Identifier et documenter chaque champ (métadonnées).
* Générer le **MCD** (Modèle Conceptuel de Données) basé sur l’analyse du CSV.
* Faire valider le MCD par le responsable (avant implémentation).

---

## **Épic 2 : Création automatique de la base de données et import des données**

### 🎯 Objectif :

Automatiser la création des tables normalisées à partir du MCD et transférer les données de la table brute vers ces tables.

### 🧩 **User Stories**

* **US2.1** : En tant qu’administrateur de base, je veux une **procédure stockée** qui crée automatiquement toutes les tables nécessaires selon le MCD.
* **US2.2** : En tant que développeur, je veux que la procédure importe les données de `import_brut` dans les bonnes tables et avec les bons types de données.
* **US2.3** : En tant qu’analyste, je veux pouvoir réimporter un nouveau CSV sans modifier la structure de la table brute.

### ✅ **Tâches**

* Créer la procédure principale `import_facturation()` :

  * Création des tables normalisées (`clients`, `adresses`, `factures`, `lignes_facture`, `produits`, etc.).
  * Conversion et insertion des données depuis `import_brut`.
* Gérer l’immuabilité des factures :

  * Une adresse modifiée ne doit pas affecter les factures passées.
  * Implémenter le principe d’unicité pour limiter les doublons.

---

## **Épic 3 : Calculs et vues de consultation**

### 🎯 Objectif :

Créer des **vues SQL** calculant les champs dérivés (HT, TVA, TTC) sans stockage redondant.

### 🧩 **User Stories**

* **US3.1** : En tant qu’utilisateur, je veux voir les montants TTC et TVA sans qu’ils soient stockés en base.

### ✅ **Tâches**

* Créer les vues suivantes :

  * `vue_facture_detaillee` : affichage HT, TVA, TTC.
  * `vue_clients_factures` : total facturé par client.
  * `vue_statistiques` (optionnelle) : chiffre d’affaires par mois.

---

## **Épic 4 : Automatisation et intégrité via triggers**

### 🎯 Objectif :

Assurer la cohérence et l’intégrité des données via des **triggers SQL**.

### 🧩 **User Stories**

* **US4.1** : En tant que système, je veux générer automatiquement un numéro de facture unique et daté à la création.
* **US4.2** : En tant qu’administrateur, je veux empêcher toute modification ou suppression d’une facture une fois créée.
* **US4.3** : En tant que système, je veux bloquer toute modification d’une facture validée.

### ✅ **Tâches**

* Créer un trigger `before insert on facture` :

  * Génère `num_facture` = `FA-AAAA-XXXX` (ou `DE`, `AV` selon le type).
  * Génère automatiquement la date du jour.
* Créer un trigger `before update on facture` :

  * Empêche la modification du numéro de facture.
* Créer un trigger `before delete on facture` :

  * Empêche la suppression d’une facture existante.
* Ajouter un champ booléen `validation` :

  * Si `validation = true`, empêcher toute modification.

---

## **Épic 5 : Backend Web – Interface et fonctionnalités**

### 🎯 Objectif :

Développer la partie backend du site pour la gestion et l’affichage des factures, avoirs et clients.

### 🧩 **User Stories**

* **US5.1** : En tant qu’utilisateur, je veux consulter la liste des factures et avoirs avec un filtrage par date et client.
* **US5.2** : En tant qu’utilisateur, je veux pouvoir **générer un avoir complet** pour annuler une facture.
* **US5.3** : En tant qu’utilisateur, je veux pouvoir **générer un avoir partiel** en sélectionnant certaines lignes de la facture.
* **US5.4** : En tant qu’utilisateur, je veux pouvoir **modifier les informations d’un client** sans impacter ses anciennes factures.

### ✅ **Tâches**

* Créer une API REST backend :

  * `GET /factures` → Liste des factures filtrables par date/client.
  * `POST /factures/:id/avoir` → Génération automatique d’un avoir complet.
  * `POST /factures/:id/avoir-partiel` → Formulaire de sélection/modification des lignes.
  * `PUT /clients/:id` → Modification de la fiche client.
* Génération automatique du numéro et date d’avoir (`AV-AAAA-XXXX`).
* Mise en place du champ `validation` pour bloquer toute modification après validation.

---

## **Épic 6 : Documentation technique et notes**

### 🎯 Objectif :

Fournir la documentation complète du projet pour assurer sa maintenance et son évolutivité.

### ✅ **Tâches**

* Documenter :

  * Les champs du CSV et leur correspondance dans le MCD.
  * Le schéma relationnel de la base.
  * Les triggers et procédures stockées.
  * Les vues SQL créées.
  * Les endpoints du backend (API REST).

---

## **💡 Livrables attendus**

1. Fichier CSV importé et table `import_brut` créée.
2. MCD validé et MLD dérivé.
3. Script SQL complet (procédures, triggers, vues).
4. Backend fonctionnel (API REST).
5. Documentation technique détaillée.

